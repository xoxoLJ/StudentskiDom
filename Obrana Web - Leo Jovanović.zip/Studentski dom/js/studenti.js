function SviPodatciStudenti(callback)
{
	var tableBody = document.getElementById('tbody1');
	tableBody.innerHTML = '';
  
	oDbStudenti.once('value', function (AllRecords)
	{
	  AllRecords.forEach(function (CurrentRecord)
	  {
		var id = CurrentRecord.val().student_id;
		var ime = CurrentRecord.val().student_ime;
		var prezime = CurrentRecord.val().student_prezime;
		var spol = CurrentRecord.val().student_spol;
		var smjer = CurrentRecord.val().student_smjer;
		var godina = CurrentRecord.val().student_godina;
		var smjestaj = CurrentRecord.val().student_smjestaj;
  
		AddItemsToTable(id, ime, prezime, spol, smjer, godina, smjestaj);
	  });
  
	  // Update stdNo after adding items to the table
	  stdNo = $('#tbody1').find('tr').length;
  
	  if (callback && typeof callback === 'function')
	  {
		callback();
	  }
	});
}

window.onload = function ()
{
	SviPodatciStudenti(function ()
	{
	  // This function will be invoked once SviPodatciStudenti completes its execution
	  console.log('SviPodatciStudenti has completed.');
	});
};

var stdNo;

function AddItemsToTable(id, ime, prezime, spol, smjer, godina, smjestaj)
{
	var tbody = document.getElementById('tbody1');
	var trow = document.createElement('tr');

	var td1 = document.createElement('td');
	var td2 = document.createElement('td');
	var td3 = document.createElement('td');
	var td4 = document.createElement('td');
	var td5 = document.createElement('td');
	var td6 = document.createElement('td');
	var td7 = document.createElement('td');
	var td8 = document.createElement('td');
	var td9 = document.createElement('td');
	var td10 = document.createElement('td');

	td1.innerHTML = tbody.getElementsByTagName('tr').length + 1; // Use length directly 
	td2.innerHTML = id;
	td3.innerHTML = ime;
	td4.innerHTML = prezime;
	td5.innerHTML = spol;
	td6.innerHTML = smjer;
	td7.innerHTML = godina;
	td8.innerHTML = smjestaj;

	// Add Edit button
    var editButton = document.createElement('button');
    editButton.innerHTML = 'Uredi';
    editButton.onclick = function ()
	{
		// Use the existing student's information
		var existingStudentData = {
			"student_id": id,
			"student_ime": ime,
			"student_prezime": prezime,
			"student_spol": spol,
			"student_smjer": smjer,
			"student_godina": godina,
			"student_smjestaj": smjestaj
		};
	
		// Populate the edit form with existing data
		$('#editStudentId').val(existingStudentData.student_id);
		$('#editStudentIme').val(existingStudentData.student_ime);
		$('#editStudentPrezime').val(existingStudentData.student_prezime);
		$('#editStudentSpol').val(existingStudentData.student_spol);
		$('#editStudentSmjer').val(existingStudentData.student_smjer);
		$('#editStudentGodina').val(existingStudentData.student_godina);
		$('#editStudentSmjestaj').val(existingStudentData.student_smjestaj);

		// Show the edit modal
		$('#editStudentModal').modal('show');
	};
    td9.appendChild(editButton);

	// Add Delete button (only if smjestaj is "ne")
    if (smjestaj === 'ne')
	{
		var deleteButton = document.createElement('button');
  		deleteButton.innerHTML = 'Izbrisi';
  		deleteButton.onclick = function ()
		{
			// Create a confirmation dialog
			var confirmation = window.confirm('Da li ste sigurni da želite izbrisati ovog studenta?');
		
			if (confirmation) {
				// User confirmed, proceed with deleting the data
				oDbStudenti.orderByChild('student_id').equalTo(id).once('value').then(function (snapshot) {
					// Get the key of the record with matching student_id
					var key = Object.keys(snapshot.val())[0];
					return oDbStudenti.child(key).remove();
				}).then(function () {
					// Refresh the table after the deletion is successful
					SviPodatciStudenti();
				}).catch(function (error) {
					// Handle the error appropriately
					console.error('Error deleting student data:', error);
				});
			}
			// If the user clicks "Cancel" in the confirmation dialog, do nothing.
		};
        td10.appendChild(deleteButton);
    }

	//trow.appendChild(td1);
	trow.appendChild(td2);
	trow.appendChild(td3);
	trow.appendChild(td4);
	trow.appendChild(td5);
	trow.appendChild(td6);
	trow.appendChild(td7);
	trow.appendChild(td8);
	trow.appendChild(td9);
    trow.appendChild(td10);

	tbody.appendChild(trow);
}

// Function to generate a unique ID
function generateUniqueId(existingId)
{
	if (existingId) {
	  // If it's an edit operation, return the existing ID
	  return Promise.resolve(existingId);
	}
  
	// If it's a new record, generate a new ID
	return oDbStudenti.orderByChild('student_id').limitToLast(1).once('value').then(snapshot =>
	{
	  	let currentHighestId = stdNo;
	  	snapshot.forEach(childSnapshot =>
			{
				let currentId = childSnapshot.val().student_id;
				let numericPart = parseInt(currentId, 10);
				if (!isNaN(numericPart))
				{
		  			currentHighestId = Math.max(currentHighestId, numericPart);
				}
	  		});
  
	  	// Increment the ID
	  	let newId = currentHighestId + 1;
  
	  	// Return the new ID as a string
	  	return newId.toString();
	}).catch(error =>{
		console.error('Error reading current highest ID from Firebase:', error);
	  	throw error;
	});
}

$(document).ready(function()
{
    $('#searchInput').on('keyup', function()
	{
      var searchText = $(this).val().toLowerCase();
      $('#myTable tbody tr').filter(function()
	  {
        $(this).toggle($(this).text().toLowerCase().indexOf(searchText) > -1);
      });
    });

	$('#addStudentForm').submit(function(event)
	{
		event.preventDefault();
	
		// Call the asynchronous function and use the generated ID
		generateUniqueId().then(function(newId)
		{
		  // Collect form data
		  	var studentData =
			{
				"student_id": newId,
				"student_ime": $('#addstudentIme').val(),
				"student_prezime": $('#addstudentPrezime').val(),
				"student_spol": $('#addstudentSpol').val(),
				"student_smjer": $('#addstudentSmjer').val(),
				"student_godina": $('#addstudentGodina').val(),
				"student_smjestaj": $('#addstudentSmjestaj').val()
		  	};

			oDbStudenti.child(newId-1).set(studentData)
			.then(function () {
				// Data successfully saved
				console.log('Data saved successfully');
			})
			.catch(function (error) {
				// Handle the error appropriately
				console.error('Error saving student data:', error);
			});
	
			 // Save data to Firebase
		  	//oDbStudenti.push(studentData); staro dodavanje u bazu

			stdNo = $('#tbody1').find('tr').length;

			SviPodatciStudenti();
	
		  	// Close the modal
		  	$('#addStudentModal').modal('hide');
	
		  	// Clear form fields
			$('#addStudentForm')[0].reset();
		});
	});

	// Edit Student Form Submission
	$('#editStudentForm').submit(function (event)
	{
		event.preventDefault();
	
		// Retrieve the student_id for the record to be edited
		var studentId = $('#editStudentId').val();

		var confirmation = window.confirm('Da li ste sigurni da želite sačuvati promjene?');

		if (confirmation)
		{
			generateUniqueId(studentId).then(function (newId)
			{
			  // User confirmed, proceed with updating the data
			  oDbStudenti.child(studentId-1).update({
				"student_id": newId,
				"student_ime": $('#editStudentIme').val(),
				"student_prezime": $('#editStudentPrezime').val(),
				"student_spol": $('#editStudentSpol').val(),
				"student_smjer": $('#editStudentSmjer').val(),
				"student_godina": $('#editStudentGodina').val(),
				"student_smjestaj": $('#editStudentSmjestaj').val()
			  }).then(function (){
				// Close the modal
				$('#editStudentModal').modal('hide');
		
				// Clear form fields
				$('#editStudentForm')[0].reset();
		
				// Refresh the table after the update is successful
				SviPodatciStudenti();
			  }).catch(function (error) {
				// Handle the error appropriately
				console.error('Error updating student data:', error);
			  });
			});
		}
	});
});