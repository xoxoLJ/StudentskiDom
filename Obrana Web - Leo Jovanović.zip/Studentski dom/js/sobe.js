function ModalUrediSobu(sSobaKey)
{
    var oSobaRef = oDbSobe.child(sSobaKey);
    oSobaRef.once('value', function(oOdgovorPosluzitelja)
    {
        var oSoba = oOdgovorPosluzitelja.val();

        $('#SobaId').val(oSoba.soba_id);
        $('#SobaVrsta').val(oSoba.soba_vrsta);
        $('#SobaKat').val(oSoba.soba_kat);

        var oSobaTroskovi = 100;

        var selectSobaStudent1 = document.getElementById('SobaStudent1');

        studentList.forEach(function(student) {
            var option = document.createElement('option');
            option.value = student.student_id;
            option.text = student.student_ime + " " + student.student_prezime;
            if (option.value != oSoba.soba_student2)
            {
                selectSobaStudent1.add(option);
            }
        });

        for (var i = 0; i < selectSobaStudent1.options.length; i++) {
            var option = selectSobaStudent1.options[i];
            if (option.value === oSoba.soba_student1) {
                option.selected = true;
                oSobaTroskovi = oSobaTroskovi + 75;
                break;
            }
            else {
                selectSobaStudent1.value = '';
            }
        }

        if (oSoba.soba_vrsta === "Dvokrevetna")
        {
            var selectSobaStudent2 = document.getElementById('SobaStudent2');

            studentList.forEach(function(student) {
                var option = document.createElement('option');
                option.value = student.student_id;
                option.text = student.student_ime + " " + student.student_prezime;
                if (option.value != oSoba.soba_student1)
                {
                    selectSobaStudent2.add(option);
                }
            });

            for (var i = 0; i < selectSobaStudent2.options.length; i++) {
                var option = selectSobaStudent2.options[i];
                if (option.value === oSoba.soba_student2) {
                    option.selected = true;
                    oSobaTroskovi = oSobaTroskovi + 75;
                    break;
                }
                else {
                    selectSobaStudent2.value = '';
                }
            }

            $('#SobaStudent2Container').show();
        } else 
        {
            $('#SobaStudent2Container').hide();
        }

        $('#SobaTroskovi').val(oSobaTroskovi + "€");

        $('#btnIzbaciStudenta1').attr('onclick', 'IzbaciStudentaIzSobe1("' + sSobaKey + '")');
        $('#btnIzbaciStudenta2').attr('onclick', 'IzbaciStudentaIzSobe2("' + sSobaKey + '")');

        $('#btnSpremiUredenuSobu').attr('onclick', 'SpremiUredenuSobu("' + sSobaKey + '")');

        $('#viewSobaModal').modal('show');
    });
}

function IzbaciStudentaIzSobe1(sSobaKey)
{
    var sSobaStudent1 = $('#SobaStudent1').val();

    var studentRef1 = oDbStudenti.child(sSobaStudent1-1);
    studentRef1.update({ student_smjestaj: 'ne' });

    var selectSobaStudent1 = document.getElementById('SobaStudent1');
    selectSobaStudent1.value = '';

    var oSobaRef = oDbSobe.child(sSobaKey);
    oSobaRef.update({ soba_student1: '' });
}

function IzbaciStudentaIzSobe2(sSobaKey)
{
    var sSobaStudent2 = $('#SobaStudent2').val();

    var studentRef2 = oDbStudenti.child(sSobaStudent2-1);
    studentRef2.update({ student_smjestaj: 'ne' });

    var selectSobaStudent2 = document.getElementById('SobaStudent2');
    selectSobaStudent2.value = '';

    var oSobaRef = oDbSobe.child(sSobaKey);
    oSobaRef.update({ soba_student2: '' });
}

function SpremiUredenuSobu(sSobaKey)
{
	var oSobaRef = oDbSobe.child(sSobaKey);

	var sSobaId = $('#SobaId').val();
    var sSobaVrsta = $('#SobaVrsta').val();
	var sSobaKat = $('#SobaKat').val();

    var sSobaStudent1 = $('#SobaStudent1').val();

	var oSoba = 
	{
		'soba_id': sSobaId, 
        'soba_vrsta': sSobaVrsta,
		'soba_kat': sSobaKat,
        'soba_student1': sSobaStudent1
	};

    if (sSobaVrsta === "Dvokrevetna")
    {
        var sSobaStudent2 = $('#SobaStudent2').val();
        oSoba['soba_student2'] = sSobaStudent2;
    }

    var confirmation = window.confirm('Da li ste sigurni da želite sačuvati promjene?');

    if (confirmation)
    {
        if (sSobaVrsta === "Jednokrevetna")
        {
            oSobaRef.update(oSoba);
        }
        else
        {
            var studentRef1 = oDbStudenti.child(sSobaStudent1-1);
            var studentRef2 = oDbStudenti.child(sSobaStudent2-1);

            studentRef1.once('value', function(snapshot1) {
                var studentData1 = snapshot1.val();
                studentRef2.once('value', function(snapshot2) {
                    var studentData2 = snapshot2.val();

                    if (studentData1.student_spol === studentData2.student_spol) {
                        if (studentData1.student_id !== studentData2.student_id){
                            oSobaRef.update(oSoba);
                        }
                        else{
                            alert("Nije moguće spremiti 2 ista studenta u sobu!");
                        }
                    } else {
                        alert("Nije moguće spremiti 2 studenta u sobu ako nemaju isti spol!");
                    }
                });
            });
        }
    }

	$('#viewSobaModal').modal('hide');

    $('#viewSobaForm')[0].reset();
}

var studentList = [];

$(document).ready(function()
{
    $('.btn.btn-sm').click(function()
    {
        var sobaId = $(this).attr('id');

        $('#SobaId').val(sobaId);

        // Remove any existing event listeners to avoid duplication
        oDbSobe.off('value');

        oDbSobe.on('value', function(AllRecords)
        {
            AllRecords.forEach(function(oSobaSnapshot)
            {
                var sSobaKey = oSobaSnapshot.key;
                var oSoba = oSobaSnapshot.val();

                if (oSoba.soba_id === sobaId)
                {
                    populateStudentList();
                    ModalUrediSobu(sSobaKey);
                }
            });
        });
    });

    function populateStudentList()
    {
        studentList = [];
        
        oDbStudenti.once('value', function(snapshot)
        {
            snapshot.forEach(function(studentSnapshot)
            {
                var student = studentSnapshot.val();

                if (student.student_smjestaj === 'da')
                {
                    oDbSobe.once('value', function(snapchat)
                    {
                        snapchat.forEach(function(sobaSnapshot)
                        {
                            var soba = sobaSnapshot.val();

                            if (student.student_id !== soba.soba_student1 || student.student_id !== soba.soba_student2)
                            {
                                var addToStudentList = true;

                                // If the student is already in studentList, set the flag to false
                                studentList.forEach(function(existingStudent) {
                                    if (existingStudent.student_id === student.student_id) {
                                        addToStudentList = false;
                                    }
                                });

                                // If addToStudentList is still true, add the student to studentList
                                if (addToStudentList) {
                                    studentList.push(student);
                                }
                            }
                        })
                    });
                }
            });
        });
    }
});