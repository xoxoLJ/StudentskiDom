var trenutniMjesec = document.getElementById('trenutniMjesec');

window.onload = function ()
{
	var troskoviStudenata = 0;

    oDbStudenti.once('value', function(snapshot)
    {
        snapshot.forEach(function(studentSnapshot)
        {
            var student = studentSnapshot.val();

            if (student.student_smjestaj === 'da')
            {
                troskoviStudenata = troskoviStudenata + 200;
            }
        });

        var tisucice = Math.floor(troskoviStudenata / 1000);
        var stotice = troskoviStudenata % 1000;

        trenutniMjesec.innerHTML = tisucice + " " + stotice + "€";
    });
};