// Inicijalizacija Firebase-a
var firebaseConfig = {
  apiKey: "AIzaSyDeD-LvzxQIx57UQj0vsOsS59VmQEcbtR0",
  authDomain: "studenti-7b575.firebaseapp.com",
  databaseURL: "https://studenti-7b575-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "studenti-7b575",
  storageBucket: "studenti-7b575.appspot.com",
  messagingSenderId: "884746962523",
  appId: "1:884746962523:web:6202e8f79da2577001217e"
};
firebase.initializeApp(firebaseConfig);

//const app = initializeApp(firebaseConfig);

// Kreiranje objekta Firebase baze
var oDb = firebase.database();
var auth = firebase.auth();
var oDbStudenti = oDb.ref('studenti');
var oDbSobe = oDb.ref('sobe');

oDbStudenti.on('value', function(snapshot) {
  console.log('Studenti data changed:', snapshot.val());
});

oDbSobe.on('value', function(snapshot) {
  console.log('Sobe data changed:', snapshot.val());
});